import { useEffect, useState } from "react";
import axios from "axios";

import logo from "./logo.svg";
import "./App.css";

function App() {
  const [count, setCount] = useState(0);
  const [data, setData] = useState();
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    axios
      .get("http://localhost:5000/players")
      .then((resp) => {
        setData(resp.data);
        setSuccess(true);
      })
      .catch((err) => {
        console.log(err);
        setError(true);
      });

    // axios
    //   .post(
    //     "http://localhost:5000/players",
    //     { playerId: 1, player },
    //     { headers: { contentType: "application/json" } }
    //   )
    //   .then((resp) => setData(resp.data))
    //   .catch((err) => console.log(err));
  }, []);
  //   console.log(data[0]?.playerName);
  return (
    <div className="App">
      {/* {data[0].playerName} */}
      <h1>react front end and backend</h1>
      {success && <h1>Success</h1>}
      {error && <h1>Error</h1>}
    </div>
  );
}

export default App;
